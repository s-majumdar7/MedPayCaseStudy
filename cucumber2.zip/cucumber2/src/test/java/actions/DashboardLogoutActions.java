package actions;
import org.openqa.selenium.WebDriver;

import elements.DashboardLogoutElements;
import steps.CommonSteps;

public class DashboardLogoutActions 
{
	    WebDriver driver;
	    DashboardLogoutElements dashboardLogoutEle;
	    DashboardLogoutActions(CommonSteps common_steps)
		{
			this.driver=common_steps.getDriver();
		}
		public void clickMenuButton()
		{
			dashboardLogoutEle.menuButton.click();
		}
		public void clickLogoutButton()
		{
			dashboardLogoutEle.logoutButton.click();
		}
	}

