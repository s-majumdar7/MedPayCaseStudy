package actions;

import org.openqa.selenium.WebDriver;

import elements.DashboardLoginElements;
import steps.CommonSteps;

public class DashboardLoginActions 
{
    WebDriver driver;
	DashboardLoginElements dashboardLoginEle;
	DashboardLoginActions(CommonSteps common_steps)
	{
		this.driver=common_steps.getDriver();
	}
	public void setUserName(String user_name)
	{
		dashboardLoginEle.userNameField.sendKeys(user_name);
	}
	public void setPassword(String password)
	{
		dashboardLoginEle.passField.sendKeys(password);
	}
	public void clickLoginButton()
	{
		dashboardLoginEle.loginButton.click();
	}
	public String getUserName()
	{
		return dashboardLoginEle.userNameField.getAttribute("value");
	}
	public String getPassword()
	{
		return dashboardLoginEle.passField.getAttribute("value");
	}
}
