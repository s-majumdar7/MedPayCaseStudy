package actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import elements.OrdersPageElements;
import steps.CommonSteps;

public class OrdersPageActions {
	WebDriver driver;
	Select order_cat;
	Select pay_cat;
	Select del_par_cat;
	OrdersPageElements orderPageEle;
	OrdersPageActions(CommonSteps common_steps)
	{
		this.driver=common_steps.getDriver();
	}
	
	public void selectOrderType(String order_type)
	{
		order_cat=new Select(orderPageEle.order_type);
		order_cat.selectByVisibleText(order_type);
	}
	public void selectPaymentCollection(String payment_collection)
	{
		pay_cat=new Select(orderPageEle.payment_collection);
		pay_cat.selectByVisibleText(payment_collection);
	}
	public void selectDeliveryPartner(String delivery_partner)
	{
		del_par_cat=new Select(orderPageEle.delivery_partner);
		del_par_cat.selectByVisibleText(delivery_partner);
	}
	
	public void clickMenuButton()
	{
		orderPageEle.menuButton.click();
	}
	public void clickPlaceOrderButton()
	{
		orderPageEle.placeOrderButton.click();
	}
	public void clickOrdersButton()
	{
		orderPageEle.ordersButton.click();
	}
	public void setName(String name)
	{
		orderPageEle.name.sendKeys(name);
	}
	public void setMobile(String mobile)
	{
		orderPageEle.mobile.sendKeys(mobile);
	}
	public void setPartnerOrderId(String p_o_id)
	{
		orderPageEle.partner_order_id.sendKeys(p_o_id);
	}
	public void setAlternativeMobile(String alternative_mobile)
	{
		orderPageEle.alternative_mobile.sendKeys(alternative_mobile);
	}
	public void setEmail(String email)
	{
		orderPageEle.email.sendKeys(email);
	}
	public void setAddress(String address)
	{
		orderPageEle.address.sendKeys(address);
	}
	public void setLandmark(String landmark)
	{
		orderPageEle.landmark.sendKeys(landmark);
	}
	
	public void setPinCode(String pin_code)
	{
		orderPageEle.pin_code.sendKeys(pin_code);
	}
	public void setCity(String city)
	{
		orderPageEle.city.sendKeys(city);
	}
	public void setState(String state)
	{
		orderPageEle.state.sendKeys(state);
	}
	
	public void setMedicineName(String medicineName)
	{
		orderPageEle.medicineName.sendKeys(medicineName);
	}
	public void selectItem()
	{
		orderPageEle.item.click();
	}
	public void clickSubmitButton()
	{
		orderPageEle.submitButton.click();
	}
	public void clickExportDataButton()
	{
		orderPageEle.exportDataButton.click();
	}
	
	
	public String getMobile()
	{
		return orderPageEle.mobile.getAttribute("value");
	}
	public String getAlternativeMobile()
	{
		return orderPageEle.alternative_mobile.getAttribute("value");
	}
	public String getEmail()
	{
		return orderPageEle.email.getAttribute("value");
	}
	public String getPinCode()
	{
		return orderPageEle.pin_code.getAttribute("value");
	}
	
	public String getPartnerOrderId()
	{
		return orderPageEle.partner_order_id.getAttribute("value");
	}
	public String getName()
	{
		return orderPageEle.name.getAttribute("value");
	}
	public String getAddress()
	{
		return orderPageEle.address.getAttribute("value");
	}
	public String getLandmark()
	{
		return orderPageEle.landmark.getAttribute("value");
	}
	
	public String getCity()
	{
		return orderPageEle.city.getAttribute("value");
	}
	public String getState()
	{
		return orderPageEle.state.getAttribute("value");
	}
	public String getMedinineName()
	{
		return orderPageEle.medicineName.getAttribute("value");
	}

}
