package actions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

import steps.CommonSteps;

public class CommonActions {
	private WebDriver driver;
	CommonActions(CommonSteps common_steps)
	{
		this.driver=common_steps.getDriver();
	}
	public void goToUrl(String url)
	{
		driver.get(url);
	}
	public String getCurrentPageUrl()
	{
		return driver.getCurrentUrl();
	}
	public String getCurrentPageTitle()
	{
		return driver.getTitle();
	}
	public void windowmaximize()
	{
		driver.manage().window().maximize();
	}
	public void navigateToUrl(String url)
	{
		driver.navigate().to(url);
	}
	public void implicitTimeOut()
	{
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}
	public void pageLoad()
	{
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
	}
	public void acceptAlert() throws Exception
	{
		Alert alert = driver.switchTo().alert(); // switch to alert
		String alertMessage= driver.switchTo().alert().getText();
		System.out.print(alertMessage);
		Thread.sleep(5000);
		alert.accept();
	}
	public void dismissAlert() throws Exception
	{
		Alert alert = driver.switchTo().alert(); // switch to alert
		String alertMessage= driver.switchTo().alert().getText();
		System.out.print(alertMessage);
		Thread.sleep(5000);
		alert.dismiss();
	}
}
