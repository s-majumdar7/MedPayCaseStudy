package elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrdersPageElements {
	WebDriver driver;
	@FindBy(xpath="//p[contains(text(),'Order Dashboard')]") public WebElement pageTitle;
	@FindBy(xpath="//body/div[@id='root']/div[1]/div[1]/button[1]/*[1]") public WebElement menuButton;
	@FindBy(linkText="Orders") public WebElement ordersButton;
	@FindBy(linkText="Export Data") public WebElement exportDataButton;
	@FindBy(linkText="Place an order") public WebElement placeOrderButton;
	@FindBy(xpath="//input[@id='partner_order_id']") public WebElement partner_order_id;
	
	@FindBy(xpath="//select[@id='order_type']") public WebElement order_type;
	@FindBy(xpath="//select[@id='payment_collection']") public WebElement payment_collection;
	@FindBy(xpath="//select[@id='delivery_partner']]") public WebElement delivery_partner;
	
	@FindBy(xpath="//input[@id='name']") public WebElement name;
	@FindBy(xpath="//input[@id='mobile']") public WebElement mobile;
	@FindBy(xpath="//input[@id='alternative_mobile']") public WebElement alternative_mobile;
	@FindBy(xpath="//input[@id='email']") public WebElement email;
	@FindBy(xpath="//input[@id='address']") public WebElement address;
	@FindBy(xpath="//input[@id='landmark']") public WebElement landmark;
	@FindBy(xpath="//input[@id='pin_code']") public WebElement pin_code;
	
	@FindBy(xpath="//input[@id='city']") public WebElement city;
	@FindBy(xpath="//input[@id='state']") public WebElement state;
	@FindBy(xpath="//input[@id='medicineName']") public WebElement medicineName;
	@FindBy(xpath="//body/div[2]/div[4]/div[1]/section[1]/div[1]/div[1]/form[1]/div[7]/div[1]/div[1]/div[1]/div[2]/p[2]") public WebElement item;
	@FindBy(linkText="Submit") public WebElement submitButton;
	
	
	
	OrdersPageElements(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}


}
