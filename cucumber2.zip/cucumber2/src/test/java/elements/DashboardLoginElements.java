package elements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardLoginElements {
	
		WebDriver driver;
		@FindBy(xpath="//p[@class='signup-titel']") public WebElement userNameTag;
		@FindBy(xpath="//input[@id='username'") public WebElement userNameField;
		@FindBy(xpath="//label[@id='field-244-label']") public WebElement passTag;
		@FindBy(xpath="//input[@id='password']") public WebElement passField;
		@FindBy(xpath="//button[contains(text(),'Login')]]") public WebElement loginButton;
		DashboardLoginElements(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}
	}


