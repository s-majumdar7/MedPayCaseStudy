package elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardLogoutElements {
	WebDriver driver;
	@FindBy(xpath="//p[contains(text(),'Order Dashboard')]") public WebElement pageTitle;
	@FindBy(xpath="//body/div[@id='root']/div[1]/div[1]/button[1]/*[1]") public WebElement menuButton;
	@FindBy(linkText="LogOut") public WebElement logoutButton;
	
	DashboardLogoutElements(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

}
