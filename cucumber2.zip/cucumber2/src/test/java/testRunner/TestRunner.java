package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"/Users/subhasmitamajumdar/eclipse-workspace/myproject/cucumber2/features"},
		glue= {"/src/test/java/steps"},
		plugin= {"pretty","html:Report"},
		dryRun=false
//		tags= "@amazon"
		)

public class TestRunner {
	

}
