package steps;

//import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;

//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.Select;

import actions.CommonActions;
import actions.OrdersPageActions;
import elements.OrdersPageElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class OrderPage {
	private WebDriver driver;
	CommonActions common_actions;
//	Select sa;
	OrdersPageElements orderPageEle;
	OrdersPageActions orderPageActions;
	
	OrderPage(CommonActions common_actions)
	{
		this.common_actions=common_actions;
	}
	@Given("User is on order page")
	public void user_is_on_order_page()
	{
		common_actions.implicitTimeOut();
		common_actions.pageLoad();
		String currtitle=driver.getTitle();
		WebElement pagetitle=orderPageEle.pageTitle;
		if(!(pagetitle.isDisplayed()))
		{
			if(currtitle.equalsIgnoreCase("order dashboard"))
				fail("user is not on orders page");
		}
	}
	@When("user open menu button")
	public void open_menu_button()
	{
		Boolean elementstatus=false;
		try
		{
			WebElement menuButton=orderPageEle.menuButton;
			elementstatus = menuButton.isDisplayed() || menuButton.isEnabled();
			orderPageActions.clickMenuButton();
		}
		catch(NoSuchElementException e)
		{
			System.out.print("Menu Button status" + elementstatus);
		}
	}
	@When("click on {string} button")
	public void click_on_button(String Orders)
	{
		Boolean elementstatus=false;
		try
		{
			WebElement oredersButton=orderPageEle.ordersButton;
			elementstatus = oredersButton.isDisplayed() || oredersButton.isEnabled();
			orderPageActions.clickMenuButton();
		}
		catch(NoSuchElementException e)
		{
			System.out.print("Orders Button status" + elementstatus);
		}
	}
	@Then("User remains on orders page")
	public void user_remains_on_orders_page() throws Exception
	{
		common_actions.dismissAlert();
		String getCurrUrl=common_actions.getCurrentPageUrl();
		String actualUrl="https://testing.d3eymc78cqte40.amplifyapp.com/orders";
		if(!(getCurrUrl.equals(actualUrl)))
		{
			fail("User is not redirected to some other page");
		}
		
	}
	
	@When("User clicks 'Export Data' button")
	public void user_clicks_export_data_button()
	{
		orderPageActions.clickExportDataButton();
	}
	
	@Then("Excel sheets gets downloaded")
	
	public static void waitForTheExcelFileToDownload(int timeWait) throws InterruptedException {
        String downloadPath="/Users/subhasmitamajumdar/Downloads/";
        File dir = new File(downloadPath);
        File[] dirContents = dir.listFiles();

        for (int i = 0; i < 3; i++) {
            if (dirContents[i].getName().equalsIgnoreCase("orders.xlsx")) {
                break;
            }else {
                Thread.sleep(timeWait);
            }
        }
    }
	
	
	@When("User clicks on 'Place an order' button")
	public void user_clicks_on_place_order_button()
	{
		Boolean elementstatus=false;
		common_actions.implicitTimeOut();
		try
		{
			WebElement placeOrderButton=driver.findElement(By.linkText("Place an order"));
			elementstatus = placeOrderButton.isDisplayed() || placeOrderButton.isEnabled();
			placeOrderButton.click();
		}
		catch(NoSuchElementException e)
		{
			System.out.print("Menu Button status" + elementstatus);
		}
	}
    @When("Enter {string} in order details")
    public void enter_partner_order_details(String p_o_id)
    {
    	orderPageActions.setPartnerOrderId(p_o_id);
    }
    @When("Select {string} in order details")
    public void select_order_type(String order_type)
    {
    	orderPageActions.selectOrderType(order_type);
    }
    @When("Select {string} in order detailss")
    public void select_payment_collection(String payment_collection)
    {
    	orderPageActions.selectPaymentCollection(payment_collection);
    }
    
    @When("Select {string} in order details")
    public void select_delivery_partner(String delivery_partner)
    {
    	orderPageActions.selectDeliveryPartner(delivery_partner);
    }
    @When("Enter {string} in customer details")
    public void enter_name(String name)
    {
    	orderPageActions.setName(name);
    }
    @When("Enter {string} in customer details")
    public void enter_mo_num(String mobile_number)
    {
    	orderPageActions.setMobile(mobile_number);
    }
    @When("Enter {string} in customer details")
    public void enter_alt_mo_num(String alternate_mobile_number)
    {
    	orderPageActions.setAlternativeMobile(alternate_mobile_number);
    }
    @When("Enter {string} in customer details")
    public void enter_email(String email_address)
    {
    	orderPageActions.setEmail(email_address);
    }
    
    @When("Enter {string} in address detailss")
    public void enter_address(String address)
    {
    	orderPageActions.setAddress(address);
    }
    @When("Enter {string} in address details")
    public void enter_landmark(String landmark)
    {
    	orderPageActions.setLandmark(landmark);
    }
    @When("Enter {string} in address details")
    public void enter_pincode(String pincode)
    {
    	orderPageActions.setPinCode(pincode);
    }
    
    @When("Enter {string} in address details")
    public void enter_city(String city)
    {
    	orderPageActions.setCity(city);
    }
    @When("Enter {string} in address details")
    public void enter_state(String state)
    {
    	orderPageActions.setState(state);
    }
    @When("Search {string} in Item Details")
    public void search_items(String item)
    {
    	orderPageActions.setMedicineName(item);
    	orderPageActions.selectItem();
    }
    
	@When("User submits an order")
	public void User_submits_an_order()
	{
		orderPageActions.clickSubmitButton();
	}
	@Then("User order is displayed on dashboard")
	public void user_order_is_displayed_on_dashboard() throws Exception
	{
		String mo_num=orderPageActions.getMobile();
		String alt_mo_no=orderPageActions.getAlternativeMobile();
		String e_mail=orderPageActions.getEmail();
		String pinCode=orderPageActions.getPinCode();
		String p_o_id=orderPageActions.getPartnerOrderId();
		String name=orderPageActions.getName();
		String addresss=orderPageActions.getAddress();
		String landmark=orderPageActions.getLandmark();
		String city=orderPageActions.getCity();
		String state=orderPageActions.getState();
		String med_name=orderPageActions.getMedinineName();
		if(!(mo_num.length()==10))
		{
			fail("User entered wrong mobile number");
		}
		else if(!(alt_mo_no.length()==10))
		{
			fail("User entered wrong mobile number");
		}
		else if(!(pinCode.length()==6))
		{
			fail("User entered wrong pin code");
		}
		else if(!(e_mail.contains("@") && e_mail.contains(".")))
		{
			fail("User entered wrong email");
		}
		
		else if(!(mo_num.isEmpty() || e_mail.isEmpty() || pinCode.isEmpty() || p_o_id.isEmpty() || name.isEmpty() || addresss.isEmpty() || landmark.isEmpty() || city.isEmpty() || state.isEmpty() || med_name.isEmpty()))
		{
			common_actions.acceptAlert();
			fail("Mandatory fields not filled");
		}
	}

}

