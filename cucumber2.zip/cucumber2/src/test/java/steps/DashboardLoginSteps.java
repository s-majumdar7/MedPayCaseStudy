package steps;

import static org.junit.Assert.fail;

import org.openqa.selenium.Alert;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import actions.CommonActions;
import actions.DashboardLoginActions;
import elements.DashboardLoginElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DashboardLoginSteps {
	private WebDriver driver;
	CommonActions common_actions;
	CommonSteps common_steps;
	DashboardLoginActions dashboard_actions;
	DashboardLoginElements dashboardLoginEle;
	DashboardLoginSteps(CommonActions common_actions)
	{
		this.common_actions=common_actions;
	}
	
	@Given("I open chrome browser")
	public void user_open_browser()
	{
		this.driver=common_steps.getDriver();
	}
	@When("I enter given URL")
	public void enterGivenUrl()
	{
		common_actions.goToUrl("https://testing.d3eymc78cqte40.amplifyapp.com/");
		common_actions.implicitTimeOut();
		common_actions.pageLoad();
	}
	@Then("I should navigate to login URL")
	public void i_should_navigate_to_login_url()
	{
		common_actions.navigateToUrl("https://testing.d3eymc78cqte40.amplifyapp.com/login");
		common_actions.windowmaximize();
	}
	
	@Given("I navigate to login URL")
	public void i_navigate_to_given_URL()
	{
		common_actions.implicitTimeOut();
		common_actions.pageLoad();
	}
	@When("I enter {string} and {string}")
	public void enter_credetials(String uname, String pass)
	{
		
//		verify username tag and username fields are displayed
		 WebElement userNameTag= dashboardLoginEle.userNameTag;
		 WebElement userNameField = dashboardLoginEle.userNameField;
		 if((userNameTag.isDisplayed()) && (userNameField.isDisplayed()))
		 {
			 dashboard_actions.setUserName(uname);
		 }
		 else
			 System.out.print("Element not found");

//		 verify password tag and password fields are displayed
		 WebElement passTag = dashboardLoginEle.passTag;
		 WebElement passField = dashboardLoginEle.passField;
		 if((passTag.isDisplayed()) && (passField.isDisplayed()))
		 {
			 dashboard_actions.setPassword(pass);
		 }
		 else
			 System.out.print("Element not found");
		
	}
	@When("I click submit button")
	public void click_submit()
	{
		WebElement loginButton = dashboardLoginEle.loginButton;
		if(loginButton.isDisplayed())
		{
			dashboard_actions.clickLoginButton();
		}
		else
			 System.out.print("Element not found");
		
	}
	@Then("I navigate to Medpay order page")
	public void i_navigate_to_Medpay_order_page() throws Exception
	{
		String uNameValue=dashboard_actions.getUserName();
		String passValue=dashboard_actions.getPassword();
		int uNameLength=uNameValue.length();
		int passnameLength=passValue.length();
		Thread.sleep(5000);
		String currUrl=common_actions.getCurrentPageUrl();
		String expUrl="https://testing.d3eymc78cqte40.amplifyapp.com/orders";
		if((uNameLength<10) || (passnameLength<4))
		{
			common_actions.acceptAlert();
		}
		else if(!(uNameValue.equals("TestUser123") && passValue.equals("123456")))
		{
			common_actions.acceptAlert();
		}
		else if(!(currUrl.equals(expUrl)))
		{
			fail("page not redirected to orders page");
		}
		else
		{
			common_actions.navigateToUrl("https://testing.d3eymc78cqte40.amplifyapp.com/orders");
			common_actions.windowmaximize();
		}
		Thread.sleep(1000);
	}

}
