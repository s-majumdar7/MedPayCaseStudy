package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class CommonSteps {
	private WebDriver driver;
	
	@Before()
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "webdriver/chromedriver");
		driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
	}
	
	@After()
	public void tearDown()
	{
		driver.quit();
	}
	public WebDriver getDriver()
	{
		return driver;
	}

}
