package steps;

import static org.junit.Assert.fail;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import actions.CommonActions;
import actions.DashboardLogoutActions;
import elements.DashboardLogoutElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DashboardLogoutSteps {
	private WebDriver driver;
	CommonActions common_actions;
	DashboardLogoutElements dashboardLogoutEle;
	DashboardLogoutActions dashboardLogoutActions;
	DashboardLogoutSteps(CommonActions common_actions)
	{
		this.common_actions=common_actions;
	}
	@Given("User is on order page")
	public void user_is_on_order_page()
	{
		common_actions.implicitTimeOut();
		common_actions.pageLoad();
		String currtitle=driver.getTitle();
		WebElement pagetitle=dashboardLogoutEle.pageTitle;
		if(!(pagetitle.isDisplayed()))
		{
			if(currtitle.equalsIgnoreCase("order dashboard"))
				fail("user is not on orders page");
		}
	}
	@When("open menu button")
	public void open_menu_button()
	{
		Boolean elementstatus=false;
		try
		{
			WebElement menuButton=dashboardLogoutEle.menuButton;
			elementstatus = menuButton.isDisplayed() || menuButton.isEnabled();
			dashboardLogoutActions.clickMenuButton();
		}
		catch(NoSuchElementException e)
		{
			System.out.print("Menu Button status" + elementstatus);
		}
	}
	@When("click on {string} button")
	public void click_on_button(String LogOut)
	{
		Boolean elementstatus=false;
		try
		{
			WebElement logoutButton=dashboardLogoutEle.logoutButton;
			elementstatus = logoutButton.isDisplayed() || logoutButton.isEnabled();
			dashboardLogoutActions.clickLogoutButton();
		}
		catch(NoSuchElementException e)
		{
			System.out.print("Logout Button status" + elementstatus);
		}
	}
	@Then("user navigate to login page")
	public void user_navigate_to_login_page() throws Exception
	{
		common_actions.acceptAlert();
		common_actions.goToUrl("https://testing.d3eymc78cqte40.amplifyapp.com/login");
		String getCurrUrl=common_actions.getCurrentPageUrl();
		String actualUrl="https://testing.d3eymc78cqte40.amplifyapp.com/login";
		if(!(getCurrUrl.equals(actualUrl)))
		{
			fail("User is not redirected to login page");
		}
		
	}

}
